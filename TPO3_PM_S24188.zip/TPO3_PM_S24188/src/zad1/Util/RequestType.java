package zad1.Util;

public enum RequestType {
    LANGUAGE_SERVER,
    CLIENT
}
