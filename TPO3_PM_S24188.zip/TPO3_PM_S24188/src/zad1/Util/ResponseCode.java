package zad1.Util;

public enum ResponseCode {
    OK,
    LANGUAGE_SERVER_NOT_FOUND,
    TRANSLATION_NOT_FOUND
}
